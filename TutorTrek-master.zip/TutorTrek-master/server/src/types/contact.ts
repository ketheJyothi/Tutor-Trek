export interface ContactInterface {
    name:string;
    email:string;
    message:string;
}