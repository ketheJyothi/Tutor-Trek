import React from "react";
const InstructorDashboard: React.FC = () => {
  return (
    <div className="p-32">
      <h1>instructor dash</h1>
    </div>
  );
};
export default InstructorDashboard;
